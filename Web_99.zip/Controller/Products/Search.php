<?php
	include_once("View/Products/Search.php");
?>