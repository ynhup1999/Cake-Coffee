<nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
    <div class="sb-sidenav-menu">
        <div class="nav">
            <div class="sb-sidenav-menu-heading">Core</div>
            <a class="nav-link" href="adminManager.php">
                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                Thống kê
            </a>
            
            <div class="sb-sidenav-menu-heading">Addons</div>
            <a class="nav-link" href="adminManager.php?mod=group&act=manage">
                <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                Quản lý nhóm thành viên
            </a>
            <a class="nav-link" href="adminManager.php?mod=Products&act=manage">
                <!--VỀ BỎ FILE QUẢN LÍ VÀO NHA NGAY MỤC Ở TRÊN tables.html đổi lại-->
                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                Quản lí sản phẩm
            </a>
            <a class="nav-link" href="adminManager.php?mod=category&act=manage">
                <!--VỀ BỎ FILE QUẢN LÍ VÀO NHA NGAY MỤC Ở TRÊN tables.html đổi lại-->
                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                Quản lí thể loại
            </a>
            <a class="nav-link" href="adminManager.php?mod=manufacturer&act=manage">
                <!--VỀ BỎ FILE QUẢN LÍ VÀO NHA NGAY MỤC Ở TRÊN tables.html đổi lại-->
                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                Quản lí nhà cung cấp
            </a>
            <a class="nav-link" href="adminManager.php?mod=user&act=manage">
                <!--VỀ BỎ FILE QUẢN LÍ VÀO NHA NGAY MỤC Ở TRÊN tables.html đổi lại-->
                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                Quản lí thành viên
            </a>

            <a class="nav-link" href="adminManager.php?mod=order&act=manage">
                <!--VỀ BỎ FILE QUẢN LÍ VÀO NHA NGAY MỤC Ở TRÊN tables.html đổi lại-->
                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                Quản lí đơn hàng
            </a>
        </div>
    </div>
    
</nav>