<footer id="copyright">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <p class="wow bounceIn"
                    data-wow-offset="250" data-wow-delay="0.3s">
                        Copyright &copy; T E C H - Store.2020
                    </p>
                </div>
            </div>
        </div>
    </footer>