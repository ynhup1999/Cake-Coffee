<form class="form-inline my-lg-0" method="POST" action="index.php?mod=products&act=resultsearch" style="margin-left: 100px;">
      <input class="form-control mr-sm-2" type="search" placeholder="Nhập tên sản phẩm, từ khóa cần tìm..." aria-label="Search" name="txtSearch" size=40>
      <button class="btn btn-outline-light my-2 my-sm-0 btnTimKiem" name="btnTimKiem" type="submit">Tìm kiếm</button>  		
</form>