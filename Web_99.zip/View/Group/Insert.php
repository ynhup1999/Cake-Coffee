<div>
<h2><span><a href="adminManager.php?mod=group&act=insert">Thêm nhóm thành viên</a></span></h2>

  	<form class="form" method="post" action="adminManager.php?mod=group&act=insert">
        <p><label>Tên nhóm (*)</label><input type="text" name="txtGroupName" id="txtGroupName" /></p>
        <p><label>&nbsp;</label><input type="submit" value="Lưu" name="btnSave" id="btnSave" /></p>
        <p id="error" class="error"></p>
    </form>

</div>